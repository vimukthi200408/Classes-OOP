﻿using System;
namespace classes
{
    public class UsePoints
    {
        static void Main(string[] args)
        {


            Point p = new Point();

            Point p = new Point();
           



        }
    }
}

