﻿using System;
namespace classes
{
    public class Line : Point
    {
        Point p1 = new Point();
        Point p2 = new Point();



        Math.Sqrt(Math.Pow((end.Y - start.Y), 2) + Math.Pow((end.X - start.X), 2));

    }
}

