﻿using System;
namespace classes
{
    public class ColoredPoint3D : Point3D
    {
        private string color;

        //constructors
        public ColoredPoint3D()
        {
            color = "Green";
        }
        public ColoredPoint3D(string color)
        {
            this.color = color;
        }

        //methods
        public void setvalues()
        {
            setx(1000);
            sety(2000);
            setz(3000);
            color = "Red";
        }

        public void setany(int x, int y, int z, string color)
        {
            setx(x);
            sety(y);
            setz(z);
            this.color = color;
        }
        
    }
}

