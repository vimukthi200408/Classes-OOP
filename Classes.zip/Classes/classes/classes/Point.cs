﻿using System;
namespace classes
{

    public class Point
    {


        private int x;
        private int y;

        //constructors
        public Point()
        {
            x = 100;
            y = 200;
        }

        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;

        }

        //setters
        public void setx(int x)
        {
            this.x = x;
        }
        public void sety(int y)
        {
            this.y = y;
        }

        //getters
        public int getx()
        {
            return x;
        }

        public int gety()
        {
            return y;
        }

        //methods
        public void setvalues()
        {
            x = 1000;
            y = 2000;
        }

        public void setany(int x, int y)
        {
            this.x = x;
            this.y = y;
        }


    }

}


