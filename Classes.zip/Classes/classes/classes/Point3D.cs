﻿using System;

namespace classes
{


    public class Point3D : Point
    {
        private int z;

        public Point3D() : base ()
        {
            z = 300;
        }
        public Point3D(int z)
        {
            this.z = z;
        }

        //getters and setters
        public void setz(int z)
        {
            this.z = z;
        }

        public int getz()
        {
            return z;
        }


        //methods
        public void setvalues()
        {
            setx(1000);
            sety(2000);
            z = 3000;
        }

        public void setany(int x, int y, int z)
        {
            setx(x);
            sety(y);
            this.z = z;
        }

    }

}

